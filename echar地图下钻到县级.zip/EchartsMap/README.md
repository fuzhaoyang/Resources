
## EchartsMap ##

>刚学Web开发不久，第一次上传项目，最近学了下Echarts3，官网貌似没有地图钻取的东西，就试着做了下 现分享给大家，哪里写的不好的还望指教！

**全国视图**
![全国视图](https://raw.githubusercontent.com/Senkongwww/EchartsMap/master/img/quanguo.png )

**省级视图**
![省级视图](https://raw.githubusercontent.com/Senkongwww/EchartsMap/master/img/sheng.png )

**市级视图**
![省级视图](https://raw.githubusercontent.com/Senkongwww/EchartsMap/master/img/shi.png )
