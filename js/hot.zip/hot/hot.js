
var mainMap;
var mapOptions;
var heatmap=null;
//获取阈值
var max = window.localStorage.getItem("max");
//设置地图参数
var baseMapParam = {
    zoomControl: true, // 缩放按钮是否显示
    disableDefaultUI: false,
    scaleControl: false, // 比例尺开关
    overviewMapControl: false, // 小黄人
    draggable:true,
    country: 'kw',
    zoom: 0, // 缩放比例
    center: { // 中心点说
        lat: 0, // 经度
        lng: 0// 纬度
    }
};
$(function(){
    //绘制地图
    // MapOption();
    //热力图绘制
    // creatHotmap();
    // 定义了一个坐标，用于地图居中34.264237, 108.977655
    var mapCenter = new google.maps.LatLng( 24.871640, 102.841884);
    // var mapCenter = new google.maps.LatLng(34.264237, 108.977655);
    // 地图参数对象
    mapOptions = baseMapParam; // 创建一个大地图对象
    mapOptions.center = mapCenter; // 中心点坐标引入
    mapOptions.minZoom = 11; // 能缩放到的最小值
    mapOptions.maxZoom = 15; // 能缩放到的最大值
    mapOptions.Zoom = 13; // 存放当前的缩放比例
    var homeLatLng = new google.maps.LatLng(24.971676,102.669319)
    // 创建地图对象到map_canvas上
    map = new google.maps.Map(document.getElementById('mainMap'),mapOptions); // 创建地图在ID为mainMap的元素上

    //创建热力图层
    heatmap = new HeatmapOverlay(map,{
            // radius should be small ONLY if scaleRadius is true (or small radius is intended)
            "radius": 0.005,//图上坐标点的半径
            "maxOpacity": 0.8,//热力图的最大透明度
            // scales the radius based on map zoom
            "scaleRadius": true,
            // if set to false the heatmap uses the global maximum for colorization
            // if activated: uses the data maximum within the current map boundaries
            //   (there will always be a red spot with useLocalExtremas true)
            "useLocalExtrema": true,
            // which field name in your data represents the latitude - default "lat"
            latField: 'lat',
            // which field name in your data represents the longitude - default "lng"
            lngField: 'lng',
            // which field name in your data represents the data value - default "value"
            valueField: 'count'//此数值对应热力图的颜色    大于8为红色  小于8以后为渐变色越来越浅
        })
    var marker1 = new MarkerWithLabel({
        icon:"pages/images/circle.png", //mark标记的文字样式
        position: homeLatLng, //mark标记的经纬度
        map: map,
        labelContent: "我是内容<hr>我是数字", //添加的文字
        labelAnchor: new google.maps.Point(65, 60),//参数为x轴y轴的坐标
        labelClass: "labels", // the CSS class for the label
        labelStyle: {opacity: 1} //设置文字的透明度
    })

    //渲染热力图
    //取对应字段成格式的塞进testData对象里

    testData={max:5000,data:[
        {lat: 25.002888, lng:102.671726, count:5000},
        {lat: 25.002888, lng:102.671726, count:5000},
        {lat: 25.002888, lng:102.671726, count:5000},
        {lat: 25.002888, lng:102.671726, count:5000},
        {lat: 25.002888, lng:102.671726, count:5000},
        {lat: 25.002888, lng:102.671726, count:5000},
        {lat: 25.002888, lng:102.671726, count:5000}, {lat: 25.002888, lng:102.671726, count:5000}


    ]};
    heatmap.setData(testData);//绘制热力图样
})
//地图绘制
function MapOption() {
    // 定义了一个坐标，用于地图居中34.264237, 108.977655
    var myLatlng = new google.maps.LatLng(34.264237, 108.977655);
    // 地图参数对象
    mapOptions = baseMapParam; // 创建一个大地图对象
    mapOptions.center = myLatlng; // 中心点坐标引入
    mapOptions.minZoom = 11; // 能缩放到的最小值
    mapOptions.maxZoom = 15; // 能缩放到的最大值
    mapOptions.Zoom = 14; // 存放当前的缩放比例
    mapOptions.mapTypeId=google.maps.MapTypeId.ROADMAP;
    // 创建地图对象到map_canvas上
    map = new google.maps.Map(document.getElementById('mainMap'),mapOptions); // 创建地图在ID为mainMap的元素上
}


